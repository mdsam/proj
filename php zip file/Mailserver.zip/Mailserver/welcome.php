<h3>Welcme <?php session_start();
 	echo @$_SESSION['sname'];
 ?>
 your account has beeb created 
to access your accout <a href="http://localhost/project10am/index.php?chk=3">Click here</a></h2>