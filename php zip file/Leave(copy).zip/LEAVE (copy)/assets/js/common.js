setInterval("generate_overview_data()", 300000);


function load_all() {
    generate_overview_data();
}

function generate_overview_data(){
    $(function() {
        $.ajax({
            type: "GET",
            url: "tickets/tickets_overview",
            success: function(html){
                $("#tickets_overview").html(html);
            }
        });
    });
    
    
}




