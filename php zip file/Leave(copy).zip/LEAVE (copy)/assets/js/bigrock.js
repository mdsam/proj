setInterval("generate_overall_counts()", 900000);
setInterval("generate_agents_chats_sales()", 5000);
setInterval("generate_agents_chats_support()", 5000);
setInterval("generate_agents_calls_sales()", 5000);
setInterval("generate_agents_calls_support()", 5000);
setInterval("generate_incidents_per_hour()", 900000);
setInterval("get_incoming_calls()", 3000);
setInterval("get_incoming_chats()", 5000);


function load_all_br () {
    generate_overall_counts();
    generate_agents_chats_sales();
    generate_agents_chats_support();
    generate_agents_calls_sales();
    generate_agents_calls_support();
    generate_incidents_per_hour();
}


function generate_overall_counts() {
    $(function() {
        $.ajax({
            type: "GET",
            url: "bigrock/overall_counts",
            success: function(html){
                $("#upper_overall_counts").html(html);
            }
        });
    });
}

function generate_agents_chats_sales() {
    $(function() {
        $.ajax({
            type: "GET",
            url: "bigrock/agents_chat/3",
            success: function(html){
                $("#logged_in_chats_sales").html(html);
            }
        });
    });
}

function generate_agents_chats_support() {
    $(function() {
        $.ajax({
            type: "GET",
            url: "bigrock/agents_chat/5",
            success: function(html){
                $("#logged_in_chats_support").html(html);
            }
        });
    });
}


function generate_agents_calls_sales() {
    $(function() {
        $.ajax({
            type: "GET",
            url: "wss/agents_calls/bigrock_sales",
            success: function(html){
                $("#logged_in_calls_sales").html(html);
            }
        });
    });
}

function generate_agents_calls_support() {
    $(function() {
        $.ajax({
            type: "GET",
            url: "wss/agents_calls/bigrock_support",
            success: function(html){
                $("#logged_in_calls_support").html(html);
            }
        });
    });
}


function generate_incidents_per_hour() {
    $(function() {
        $.ajax({
            type: "GET",
            url: "bigrock/overall_counts_chart",
            success: function(html){
                $("#dummy").html(html);
            }
        });
    });
}


function get_incoming_calls() {
    $(function() {
        $.ajax({
            type: "GET",
            url: "bigrock/incoming_calls/",
            success: function(msg){
                
                $("#incoming_calls").html(msg);
                if(msg.length > 0) {
                    //                    alert(msg.length);
                    $("#incoming_calls").addClass("incoming");
                    $("#incoming_calls").fadeTo("1000", 0.9);
                }
                else {
                    $("#incoming_calls").removeClass("incoming");
                    $("#incoming_calls").fadeOut("1000");
                }
            }
        });
    });
}



function get_incoming_chats() {
    $(function() {
        $.ajax({
            type: "GET",
            url: "bigrock/incoming_chats",
            success: function(msg){
                //                                alert("Msg: " + msg.length);
                
                $("#incoming_chats").html(msg);
                if(msg.length > 0) {
                    $("#incoming_chats").addClass("incoming");
                    $("#incoming_chats").fadeTo("1000", 0.9);
                }
                else {
                    $("#incoming_chats").removeClass("incoming");
                    $("#incoming_chats").fadeOut("1000");
                }
            }
        });
    });
}