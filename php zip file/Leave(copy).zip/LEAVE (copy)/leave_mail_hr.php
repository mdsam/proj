<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <title> Approved Leaves for last 10 days </title>
        
<style type="text/css">
table {	
	border-width: 1px;
	border-spacing: 1px;
	border-style: outset;
	border-color: green;
	border-collapse: separate;
	background-color: rgb(255, 250, 250);
}
table th {
	border-width: 1px;
	padding: 1px;
	border-style: none;
	border-color: blue;
	background-color: rgb(220, 240, 230);
	-moz-border-radius: ;
}
table td {
	border-width: 1px;
	padding: 1px;
	border-style: none;
	border-color: blue;
	background-color: rgb(250, 240, 230);
	-moz-border-radius: ;
}

</style>

    </head>
<body>
	

<?php

if(date("d",time())>=1 && date("d",time())<=10){
	$from_date = date("Y-m-d", mktime(0, 0, 0, date("m", time())-1, 21, date("Y", time())));
	//$to_date = date("Y-m-d", mktime(0, 0, 0, date("m", time())-1, date("d", time())-1, date("Y", time())));
	}else if(date("d",time())>=11 && date("d",time())<=20){
		$from_date = date("Y-m-d", mktime(0, 0, 0, date("m", time()), 1, date("Y", time())));
		//$to_date = date("Y-m-d", mktime(0, 0, 0, date("m", time()), 10, date("Y", time())));
		}else if(date("d",time())>=21 && date("d",time())<=28){
			$from_date = date("Y-m-d", mktime(0, 0, 0, date("m", time()), 11, date("Y", time())));
			//$to_date = date("Y-m-d", mktime(0, 0, 0, date("m", time()), 20, date("Y", time())));
			}else{
				die("something wrong");
				}
$to_date = date("Y-m-d", time());
echo "<h3 align='center'> Support : Approved Leaves from ".$from_date." to ".$to_date."</h3>";
//attempt a connection

$connect = mysql_connect("localhost", "root", "qwedsa");
 if (!$connect) {
     die("Error in connection".mysql_error());
 }
mysql_select_db("calendar_app",$connect);

// execute query
$query = "SELECT u.username, d.dept_name, date_format(ld.date,'%e') as date FROM leave_data ld, user u, department d WHERE ld.user_id = u.id AND u.dept_id = d.dept_id AND ld.date between '{$from_date}' and '{$to_date}' order by u.username"; 
//echo $query;exit;

$names = mysql_query($query);
if (!$names) {
    die('Invalid query: ' . mysql_error());
}
		
				
$tab = "<table border='1' align='center'>
	<tr>
		<th>User Name</th><th>Leave Date</th>
		</tr>";
			while ($value = mysql_fetch_array($names)) {
					//$tab .= "<tr><td>".$value['username']."</td><td>".$value['date']."</td></tr>";
					$name[$value['dept_name']][$value['username']][] = $value['date'];					
				}
		
			foreach($name as $key=>$value){
				$tab .= "<tr><th>".$key."</th></tr>";
				foreach($value as $name=>$dates){
					$tab .= "<tr><td>".$name."</td><td>";
						foreach($dates as $val){
							$tab .= $val.", ";
							}
						$tab .= "</td></tr>";
						}
						//$tab .= "</tr>";
				}	
$tab .= "</table>";
?>
</body>
</html>

<?php
//create mail 
        $subject = "Approved Leaves for last 10 days";

        //begin of HTML message
        $message =
                "<html>
                <head>
                <style type='text/css'>
table {	
	border-width: 1px;
	border-spacing: 1px;
	border-style: outset;
	border-color: green;
	border-collapse: separate;
	background-color: rgb(255, 250, 250);
}
table th {
	border-width: 1px;
	padding: 1px;
	border-style: none;
	border-color: blue;
	background-color: rgb(220, 240, 230);
	-moz-border-radius: ;
}
table td {
	border-width: 1px;
	padding: 1px;
	border-style: none;
	border-color: blue;
	background-color: rgb(250, 240, 230);
	-moz-border-radius: ;
}

</style>
                </head>
                <body>                
                <h3><b>Support : Approved Leaves from ".$from_date." to ".$to_date."</b></h3>
                <br>
                $tab
				<br><a href='http://support/leave/leave_mail_hr.php'>View in Browser</a>
				</body></html>";
        //end of message
        // To send the HTML mail we need to set the Content-type header.
        

        $headers = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html;charset=iso-8859-1' . "\r\n";
        $headers .= 'From: Leave_admin <leave_admin@intranet.directi.com>' . "\r\n";
        $headers .= "cc: t-supp-ws@intranet.directi.com,t-hob-all@intranet.directi.com";

       if (!($_SERVER['HTTP_USER_AGENT'])) {
			mail('hrops@directi.com', $subject, $message, $headers);
			//mail('vijay.r@directi.com', $subject, $message, $headers);
		}else{
		  echo $tab;
		}
?>
