<?php

class Login_model extends CI_Model {

    function validate($data) {

//        $ldapconn = @ldap_connect('172.16.140.33');
        $ldapconn = @ldap_connect('internal.directi.com');
        if ($ldapconn) {
            $ldapbind = @ldap_bind($ldapconn, $data['username'], $data['password']);
            if ($ldapbind) {
                $output = 'success';
                
            } else if ($this->input->post('username')=='admin' && $this->input->post('password')=='admin') {
            	$output = 'success';
            	} else {
                $output = 'fail';
            }
        }
        return $output;
    }

    function user_details($data) {
        $u_query = $this->db->query("SELECT * FROM user where username='" . $data['username'] . "'");

        if ($u_query->num_rows() > 0) {
            return $u_query->result();
        } else {
            die("user is not added in DB, please contact site admin (t-supp-auto@intranet.directi.com).");
        }
    }

}

?>
