<?php

class Calendar_model extends CI_Model {

    function get_names($query) {
        $list = $this->db->query($query);
        return $list->result();
    }

    function month_leave_count($leave_count) {
        $count = $this->db->query($leave_count);
        return $count->result();
    }

    function leave_taken() {
        $query = "select dates, reason from leave_app_data where id in (select distinct(leave_app_data_id) from leave_data where user_id=(SELECT id from user where username='".$this->session->userdata('username')."') and date > '".date("Y-01-01", time())."') order by timestamp desc limit 10";
        //echo $query;exit;
        $leave_taken = $this->db->query($query);
        return $leave_taken->result();
    }

    function admin_pending_approval() {
        $query = "select ld.id, u.username, ld.dates,ld.reason from leave_app_data ld, user u where u.id=ld.user_id and ld.status_id=1 and ld.user_id in (select distinct(user_id) from user_mgr_map where mgr_id in (select um.mgr_id from user u, user_mgr_map um where u.id=um.mgr_id and u.username='" . $this->session->userdata('username') . "'))";
        $leave_taken = $this->db->query($query);
        return $leave_taken->result();
    }

    function user_pending_approval() {
        $query = "select ld.id, u.username, ld.dates,ld.reason from leave_app_data ld, user u where u.id=ld.user_id and ld.status_id=1 and ld.user_id in (select id from user where dept_id = (select dept_id from user where username='" . $this->session->userdata('username') . "'))";
        $leave_taken = $this->db->query($query);
        return $leave_taken->result();
    }

    function all_pending_approval($filter) {
		if (!$filter || $filter =='all'){
		$query = "select ld.id, u.username, ld.dates from leave_app_data ld, user u where u.id=ld.user_id and ld.status_id=1";
			}else{
        $query = "select ld.id, u.username, ld.dates from leave_app_data ld, user u where u.id=ld.user_id and u.dept_id=$filter and ld.status_id=1";
			}
        $leave_taken = $this->db->query($query);
        return $leave_taken->result();
    }

    function total_leave_taken() {
/*    	        $month = array(1, 2, 3);
        if (in_array(date('n'), $month)) {
        $query = "SELECT u.username, count(*) as count FROM user u, leave_data ld where u.id=ld.user_id and date between '(".(date('Y')-1)."-04-01' and '" . date('Y') . "-03-31' and user_id in (SELECT id from user where dept_id = (select dept_id from user where username='" . $this->session->userdata('username') . "')) group by u.username";
        } else {
        	        $query = "SELECT u.username, count(*) as count FROM user u, leave_data ld where u.id=ld.user_id and date between '" . date('Y') . "-04-01' and '".(date('Y')+1)."-03-31' and user_id in (SELECT id from user where dept_id = (select dept_id from user where username='" . $this->session->userdata('username') . "')) group by u.username";
        	        }*/
        	        
  			$query = "SELECT u.username, count(*) as count FROM user u, leave_data ld where u.id=ld.user_id and date between '" . date('Y') . "-01-01' and '".date('Y')."-12-31' and user_id in (SELECT id from user where dept_id = (select dept_id from user where username='" . $this->session->userdata('username') . "')) group by u.username";
  			      	        
        $total_leave_taken = $this->db->query($query);
        return $total_leave_taken->result();
    }
    
        function total_leave_by_user() {
    	$total_leave = $this->db->query("SELECT username, leave_bal FROM user WHERE dept_id = (select dept_id from user where username='" . $this->session->userdata('username') . "')");
    	return $total_leave->result();
    	}

    function leave_balance() {
/*        $month = array(1, 2, 3);
        if (in_array(date('n'), $month)) {
            $query = "select count(*) as count from leave_data where date between '(".(date('Y')-1)."-04-01' and '" . date('Y') . "-03-31' and user_id = (select id from user where username = '" . $this->session->userdata('username') . "')";
        } else {
            $query = "select count(*) as count from leave_data where date between '" . date('Y') . "-04-01' and '".(date('Y')+1)."-03-31' and user_id = (select id from user where username = '" . $this->session->userdata('username') . "')";
        }*/
        
        $query = "select count(*) as count from leave_data where date between '" . date('Y') . "-01-01' and '". date('Y') ."-12-31' and user_id = (select id from user where username = '" . $this->session->userdata('username') . "')";

        $leave_balance = $this->db->query($query);
        return $leave_balance->result();
    }
    
    function total_leave() {
    	$total_leave = $this->db->query("SELECT leave_bal FROM user WHERE username = '" . $this->session->userdata('username') . "'");
    	return $total_leave->result();
    	}

}

?>
