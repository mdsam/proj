<?php

class Add_user_model extends CI_Model {

    function get_dept() {
        $this->db->select('dept_id, dept_name');
        $department = $this->db->get('department');
        return $department->result();
    }

    function get_admin() {
        $admins = $this->db->query('SELECT id, username FROM user WHERE is_admin=1');
        return $admins->result();
    }

    function add_user($user) {
        $this->db->insert('user', $user);
        $mgr = $this->db->query("select id from user where username='" . $user['username'] . "'");
        return $mgr->result();
    }

    function add_user_mgr($umgr) {

        $user_mgr['user_id'] = $umgr['user_id'];

        foreach ($umgr['mgr_id'] as $value) {
            $user_mgr['mgr_id'] = $value;
            $this->db->insert('user_mgr_map', $user_mgr);
        }
    }

    function get_users() {
        $users = $this->db->query('SELECT u.id, u.username, d.dept_name, u.leave_bal, u.is_admin FROM user u, department d WHERE u.dept_id=d.dept_id order by d.dept_name desc, u.is_admin desc');
        return $users->result();
    }

    function get_mgrs() {
        $users = $this->db->query('SELECT u.username as mgr, um.user_id FROM user u, user_mgr_map um WHERE u.id=um.mgr_id');
        return $users->result();
    }

    function delete_user($id) {
        //$this->db->delete('user', array('id' => $id));
        //$this->db->delete('user_mgr_map', array('user_id' => $id));
        //$this->db->delete('user_mgr_map', array('mgr_id' => $id));
        $this->db->where('id', $id);
        $this->db->update('user', array('user_status' => 'deleted'));
    }
    
    function edit_user($id) {     
        $edit_user = $this->db->get_where('user', array('id' => $id));
        return $edit_user->result();
        }
        
    function update_user($user) {
    	  //$this->db->delete('user_mgr_map', array('user_id' => $id));
        //$this->db->delete('user_mgr_map', array('mgr_id' => $id));
        
        $this->db->where('id', $user['id']);
        $this->db->update('user', $user);
        }
        
    function get_user($id) {
    	  $user = $this->db->query('SELECT * FROM user u, department d WHERE u.dept_id=d.dept_id and id='.$id);
        return $user->result();
    	}
    	
    function get_mgr($id) {
    	  $mgr = $this->db->query('SELECT u.username FROM user u, user_mgr_map um WHERE u.id=um.mgr_id and um.user_id='.$id);
        return $mgr->result();
    	}
    	
    function update_user_mgr($umgr) {
    	  
    	  $this->db->delete('user_mgr_map', array('user_id' => $umgr['user_id']));
        $this->db->delete('user_mgr_map', array('mgr_id' => $umgr['user_id']));

        $user_mgr['user_id'] = $umgr['user_id'];

        foreach ($umgr['mgr_id'] as $value) {
      	   $user_mgr['mgr_id'] = $value;
            $this->db->insert('user_mgr_map', $user_mgr);
        }
    }
}
?>
