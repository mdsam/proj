<?php

class Add_leave_model extends CI_Model {

    function apply_leave() {
        $data['dates'] = $this->input->post('dates');
        $data['reason'] = $this->input->post('reason');

        $user_id = $this->db->query("select id from user where username='" . $this->session->userdata('username') . "'");
        foreach ($user_id->result() as $value) {
            $data['user_id'] = $value->id;
        }
        $this->db->insert('leave_app_data', $data);
        
        $mgr_names = $this->db->query("SELECT u.username as mgr FROM user u, user_mgr_map um WHERE u.id=um.mgr_id and um.user_id = (select id from user where username = '".$this->session->userdata('username')."')");
        
        return $mgr_names->result();        
    }

    function approve_leave($id) {
    	if (!($this->session->userdata('is_logged_in') == true)){
				redirect('login');   		
    		}
        //$this->db->where('id', $id);
        
        //$this->db->update('leave_app_data', array('status_id' => 2));
        
        $this->db->query("UPDATE leave_app_data SET status_id = 2, approver_id = (select id from user where username = '".$this->session->userdata('username')."') WHERE id = $id");

        //$leave_approved = $this->db->get_where('leave_app_data', array('id' => $id));
        
        $leave_approved = $this->db->query("SELECT lad.id as app_id, u.id, u.username, lad.dates, lad.reason FROM user u, leave_app_data lad WHERE u.id=lad.user_id and lad.id=$id");

        foreach ($leave_approved->result() as $value) {
            $data['leave_app_data_id'] = $value->app_id;
            $data['user_id'] = $value->id;
            $dates = $value->dates;
        }
        $date = (explode(",", $dates));
        foreach ($date as $val) {
            $data['date'] = $val;
            $this->db->insert('leave_data', $data);
        }
        return $leave_approved->result();
    }

    function decline_leave($id) {
        $this->db->where('id', $id);
        $this->db->update('leave_app_data', array('status_id' => 3));
        
        $leave_decline = $this->db->query("SELECT u.username, lad.dates, lad.reason FROM user u, leave_app_data lad WHERE u.id=lad.user_id and lad.id=$id");
        return $leave_decline->result();
    }

}

?>