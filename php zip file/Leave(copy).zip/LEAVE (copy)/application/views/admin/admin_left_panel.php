<table border="1" width="300"><tr>
            <th colspan="2">Total Leaves taken by users</th></tr>
            <?php
            foreach ($total_leave_taken as $value) {
                echo '<tr><td>';
                echo $value->username;
                echo "</td><td>";
                foreach ($total_leave_by_user as $val){
						if ($val->username == $value->username)
							echo $value->count."/".$val->leave_bal;             	
                	}                
                echo '</td></tr>';
            }
            ?>
</table>