<link rel="stylesheet" href="<?= base_url(); ?>assets/css/common_new.css" type="text/css" />
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.14/jquery-ui.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.14/jquery-ui.js"></script>
<link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.14/themes/base/jquery-ui.css" type="text/css" media="all" />
<link rel="stylesheet" href="http://static.jquery.com/ui/css/demo-docs-theme/ui.theme.css" type="text/css" media="all" />

<div id="admin_right">
    <table border="1" width="300"><tr>
            <th colspan="4">Leaves Waiting for Approval</th></tr><tr>
        <?php
        $i = 0;
        foreach ($admin_pending_approval as $value) {
            echo '<tr><td>';
            echo $value->username;
            echo "</td><td>";
            $dates = (explode(",", $value->dates));

            foreach ($dates as $date) {
                echo $date;
                echo '<br>';
            }
            echo "</td><td>";
            echo $value->reason;
            echo "</td><td>
<form name='approve' action=" . base_url() . "calendar/approve_leave/" . $value->id . " id='approve' method='post'>
<input type='submit' value='Approve' />
</form>


<button id='opener{$value->id}' type='button'>Decline</button>

 <div id='dialog{$value->id}' title='Decline Reason'>
        <form name='dec_form' action=" . base_url() . "calendar/decline_leave/" . $value->id . " id='decline' method='post'>
            <textarea rows='5' cols='30' name='dec_data'> </textarea>
            <input type='submit' value='Submit' />
	                         </form>
    </div>

</td></tr>"; ?>

            <script>
                // increase the default animation speed to exaggerate the effect
                $.fx.speeds._default = 1000;
                $(function() {
                    $( "#dialog<?= $value->id ?>" ).dialog({
                        autoOpen: false,
                        show: "slide",
                        hide: "explode",
                        closeOnEscape: true,
                        draggable: false,
                        resizable: false,
                        width: 380,
                        modal: true
                    });

                    $( "#opener<?= $value->id ?>" ).click(function() {
                        $( "#dialog<?= $value->id ?>" ).dialog( "open" );
                        return false;
                    });

                });
            </script>
        <?php
            $i = $i + 1;
        }
        ?>


        </tr></table>
</div>