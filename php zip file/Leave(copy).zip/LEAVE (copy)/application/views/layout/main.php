<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
    <head>
        <title>Calendar</title>

        <script type="text/javascript">
            function show_alert()
            {
	
<?php
if (!$this->session->userdata('is_logged_in')) {
    echo "alert('Please login first for apply leave!')";
} else {
    echo "window.open('" . base_url() . "calendar/add_leave', 'Add_Leave', 'status = 0, height = 500, width = 700, resizable = 1, screenX=400,screenY=400,top=400,left=400')";
};
?>	

            }
        </script>

    </head>
    <body>
        <div id='msg'><?php echo $msg; ?></div>



        <?php
        echo "<div id ='cal_view'>";
        echo "<table align='center'><tr><td>";
        echo "</td><td>
        <div class='nav' align='center'>
    <a href=".base_url()."calendar/index/".($month - 1)."/".$year."> << </a>
    <a href=".base_url()."calendar/>Current Month</a>
    <a href=".base_url()."calendar/index/".($month + 1)."/".$year."> >> </a>
		  </div> 
			</td><td></td></tr><tr><td><div style='height: 850px; overflow:auto;'>";
        $this->load->view($left_side_panel);
        echo "</div></td><td>";
        $this->load->view($main_content);
        echo "</td><td><div style='height: 850px; width:300px; overflow:auto;'>";
        $this->load->view($right_side_panel);
        echo "</div></td></tr></table>";
        echo "</div>";
        ?>
<FONT SIZE="3" FACE="courier" COLOR=blue><MARQUEE BEHAVIOR=SCROLL HEIGHT=25 WIDTH=600>For better view use Firefox or Chrome</MARQUEE></FONT>
    </body>
    </html>
