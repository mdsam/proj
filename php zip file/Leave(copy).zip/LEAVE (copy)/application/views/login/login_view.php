<!DOCTYPE html>

<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html"; charset=utf-8>
              <title>Login</title>
        <link rel="stylesheet" href="<?php echo base_url(); ?>css/login_style.css" type="text/css" media="screen" charset="utf-8">

    </head>
    <body>

        <div id="login_form">
            <h1>Login Here!</h1>
            <?php echo validation_errors(); ?>
            <form method="post" id="login" name="login">
                <?php
                //echo form_open('login');
                echo form_input('username', '');
                echo form_password('password', '');
                echo form_submit('submit', 'Login');
                //echo form_close();
                ?>
            </form>
        </div>

    </body>
</html>