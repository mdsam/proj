<!DOCTYPE HTML>
<html>
    <head>
        <title>Add Leave</title>
        <script type="text/javascript" src="<?= base_url(); ?>assets/js/jquery_1.4.4.js"></script>
        <script type="text/javascript" src="<?= base_url(); ?>assets/js/jquery-ui_1.8.7.js"></script>
        <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/mdp.css">

        <!-- loads mdp -->
        <script type="text/javascript" src="<?= base_url(); ?>assets/js/jquery-ui.multidatespicker.js"></script>

        <style type="text/css">
            td {color:blueviolet; font-weight: bold;}
            body {background-color:bisque;}
        </style>
        <script type="text/javascript">
            $(function() {
                // Documentation //
                $('i:contains(type)').attr('title', '[Optional] accepted values are: "allowed" [default]; "avoided".');
                $('i:contains(format)').attr('title', '[Optional] accepted values are: "string" [default]; "object".');
                $('#how-to h4').each(function () {
                    var a = $(this).closest('li').attr('id');
                    $(this).wrap('<a href="#'+a+'"></a>');
                });


                // DEMOS //
                // simpliest-usage
                $('#simpliest-usage').multiDatesPicker();

                // simple-select-days-range
                $('#simple-select-days-range').multiDatesPicker({
                    mode: {
                        modeName: 'daysRange',
                        options : {autoselectRange: [0,5]}
                    }
                });

                // pre-select-dates
                $('#pre-select-dates').multiDatesPicker({
                    addDates: ['10/14/2010', '11/14/2010', '12/14/2010', '01/14/2011']
                });

                // disable-dates
                $('#disable-dates').multiDatesPicker({
                    addAvoidedDates: ['10/1/2010', '11/2/2010', '12/3/2010', '01/4/2011']
                });

                // disable-dates
                $('#dates').multiDatesPicker();

                // multi-months
                $('#multi-months').multiDatesPicker({
                    numberOfMonths: 4
                });

            });
        </script>


    </head>
    <body >
        <div align="center" >

            <h2>Apply For Leave!</h2>

            <?php echo validation_errors(); ?>
            <?php //echo form_open('leave_app_send'); ?>
            <form method ="post" id="form" name="form" onSubmit="setTimeout('window.close()',5000)">
                <table border="1">
                    <tr><td>Reason: </td><td><textarea rows="5" cols="40" name="reason"></textarea></td></tr>
                    <tr><td>Dates: </td><td>
                            <input type="text" id="dates" name="dates" READONLY style="height: 20px; overflow:auto; visibility: visible; width: 300px;" size="45">

                        </td></tr>
                    <tr><td colspan="2" align="center"><input type="submit" value="Apply for Leave"></td></tr>
                </table>
            </form>
        </div>

    </body>
</html>