Your Leave application has been sent for approval!
<p>
You can close this window now
<p>
<input type=button onClick="self.close();" value="Close this window">
<p>