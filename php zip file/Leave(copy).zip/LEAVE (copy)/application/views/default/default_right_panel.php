<table border="1" width="300"><tr>
            <th colspan="2">Leave Taken in this month</th></tr>
            <?php
            foreach ($leave_count as $value) {
                echo '<tr><td>';
                echo $value->username;
                echo "</td><td>";
                echo $value->count;
                echo '</td></tr>';
            }
            ?>
</table>
