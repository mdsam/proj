<table border="1" width="300"><tr>				
        <th colspan="2">Leaves Waiting For Approval</th>
        <?php
        foreach ($all_pending_approval as $value) {
            echo '<tr><td>';
            echo $value->username;
            echo "</td><td>";
            $dates = (explode(",", $value->dates));

            foreach ($dates as $date) {
                echo $date;
                echo '<br>';
            }
            echo "</td></tr>";
        }
        ?>
</table>