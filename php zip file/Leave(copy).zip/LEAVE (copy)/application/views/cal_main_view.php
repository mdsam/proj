<script type="text/javascript" src="<?= base_url(); ?>assets/js/jquery-1.2.2.pack.js"></script>
<script type="text/javascript" src="<?= base_url(); ?>assets/js/htmltooltip.js"></script>
<link rel="stylesheet" href="<?= base_url(); ?>assets/css/common_new.css" type="text/css" />

<?php
$first_day = mktime(0, 0, 0, $month, 1, $year);
$title = date('F', $first_day);
$day_of_week = date('D', $first_day);
switch ($day_of_week) {
    case "Sun": $blank = 0;
        break;
    case "Mon": $blank = 1;
        break;
    case "Tue": $blank = 2;
        break;
    case "Wed": $blank = 3;
        break;
    case "Thu": $blank = 4;
        break;
    case "Fri": $blank = 5;
        break;
    case "Sat": $blank = 6;
        break;
}
$days_in_month = cal_days_in_month(0, $month, $year);
?>

<?php
echo "<table id='cal_main_view' border=6>";
echo "<tr id='cal_title'><th colspan=7> $title $year </th></tr>";
echo "<tr><th width=62><div id='sunday'>Sun</div></th><th width=62>Mon</th><th width=62>Tue</th><th width=62>Wed</th><th width=62>Thu</th><th width=62>Fri</th><th width=62>Sat</th></tr>";
$day_count = 1;
echo "<tr class='day'>";
while
 ($blank > 0) {
    echo "<td></td>";
    $blank = $blank - 1;
    $day_count++;
}
$day_num = 1;
while
 ($day_num <= $days_in_month) {

//here is magic start
    $match_day = $day_num . '-' . $month . '-' . $year;
    if (date('j-n-Y') == $match_day) {
        echo "<td OnClick='show_alert()'><div class='today'>$day_num</div>";
    } else {
        echo "<td OnClick='show_alert()'>$day_num";
    }
    
echo "<div style= 'height: 100px; overflow:auto;'>";
    foreach ($names as $key => $value) {
        if ($value->date == $day_num) {
            $currUser = $value->username;
            $reason = $value->reason;
            //echo "<div class='username'>$currUser<b>: $reason</b></div>";
            echo "<a style='text-decoration:none; postion:relative; float:right;'  rel='htmltooltip'>$currUser</a><br/>";
            if ($this->session->userdata('is_logged_in') == true) {
            echo "<div class='htmltooltip'>$currUser - $reason</div>";
            }
        }
    }

	echo "</div>";
    echo "</td>";
//magic end

    $day_num++;
    $day_count++;
    if ($day_count > 7) {
        echo "</tr><tr class='day'>";
        $day_count = 1;
    }
}
while
 ($day_count > 1 && $day_count <= 7) {
    echo "<td> </td>";
    $day_count++;
}
echo "</tr></div></table>";
?>
