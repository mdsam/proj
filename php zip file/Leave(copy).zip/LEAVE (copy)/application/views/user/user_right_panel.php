
<table border="1" width="300"><tr>
        <th width="100" colspan="2" >Records of taken leaves</th></tr>
    <?php
    foreach ($leave_taken as $value) {
        echo '<tr><td>';
        $dates = (explode(",", $value->dates));
        foreach ($dates as $date) {
            echo $date;
            echo '<br>';
        }
        echo "</td><td>";
        echo $value->reason;
        echo '</td></tr>';
    }
    echo "<tr><th colspan='2'>";
    foreach ($leave_balance as $val) {
        	       $leave_taken = $val->count;
    }
    
        foreach ($total_leave as $leave) {
               $total_leave = $leave->leave_bal;
    }
    echo "Total balance leave: ";
    echo $total_leave-$leave_taken;
    echo '</th></tr>';
    ?>
</table>
