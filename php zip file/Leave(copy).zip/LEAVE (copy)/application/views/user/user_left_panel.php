
<table border="1" width="300"><tr>
            <th colspan="3">Leaves Waiting for Approval</th></tr>
            <?php
            foreach ($user_pending_approval as $value) {
                echo '<tr><td>';
                echo $value->username;
                echo "</td><td>";
                $dates = (explode(",", $value->dates));

                foreach ($dates as $date) {
                    echo $date;
                    echo '<br>';
                                    }
                echo "</td><td>";
                echo $value->reason;
                echo '</td></tr>';
            }
            
            ?>
</table>
