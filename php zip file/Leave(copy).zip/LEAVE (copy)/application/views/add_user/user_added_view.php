User has been added successfuly!

<a href="<?php echo base_url(); ?>add_user">Add more users</a><br>
<a href=<?php echo base_url();?> >Back to Calendar</a>