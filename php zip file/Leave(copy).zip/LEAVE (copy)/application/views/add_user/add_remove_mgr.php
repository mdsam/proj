<!DOCTYPE html>

<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html"; charset=utf-8>
              <title>Add Remove Manager</title>
    </head>
    <body>

        <div id="add_remove_mgr">
            <h1>Add Remove Manager</h1>
            <?php //echo validation_errors(); ?>
            <?php echo form_open("add_user/update_mgrs/".$id); ?>
           <!-- <form method="post" id="edit_user" name="edit_user"> -->
                <table border="1">
                    <tr><td>User Name: </td><td><?php echo $username; ?></td></tr>
                    <tr><td>Leave Balanace: </td><td><?php echo $leave_bal; ?></td></tr>

                    <tr><td>Department: </td><td><?php echo $department; ?></td></tr>

                    <tr><td>is_admin: </td><td><input type="checkbox" name="is_admin" 
                    <?php
                    if ($is_admin==1){
                    	echo "checked='1'";
                    	}
                    	?>
                    	></td></tr>
                    	
							<tr><td>Current Managers: </td><td>
							<?php
							  foreach ($mgr as $value){
									echo $value->username;
									echo " ";							  	
							  	} 
							 ?>
							</td></tr>
							
							<tr><td>Edit Managers: </td><td><select name="mgrs[]" multiple="managers" size="4">

                                <?php
                                foreach ($admin as $value) {
                                    echo "<option value='" . $value->id . "'";
                                    
                                    foreach ($mgr as $val){
                                    if ($value->username == $val->username) { //adds selected attribute
                                        echo " selected='selected'";
                                    }
                                    }
                                    echo ">" . $value->username . "</option>";
                                }
                                ?>
                            </select></td></tr>
							
                    <tr><td colspan="2" align="center"><input type="submit" value="Update"></td></tr>
                </table>
            
        </div>
        
<a href="<?php echo base_url(); ?>index.php/add_user">Cancel</a><br>
<a href=<?php echo base_url();?> >Back to Calendar</a>        
        
    </body>
</html>
