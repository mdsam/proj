<!DOCTYPE html>

<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html"; charset=utf-8>
              <title>Add User</title>

<script>
function confirmDelete(delUrl) {
  if (confirm("Are you sure you want to delete")) {
    document.location = delUrl;
  }
}
</script>

    </head>
    <body>

        <div id="login_form">
            <h1>Add User</h1>
            <?php //echo validation_errors(); ?>
            <form method="post" id="add_user" name="add_user" action="add_user/add">
                <table border="1">
                    <tr><td>User Name: </td><td><input type="text" name="username" ></td></tr>
                    <tr><td>Leave Balanace: </td><td><input type="text" name="leave_bal" value="24"></td></tr>

                    <tr><td>Department: </td><td><select name="dept">
                                <?php
                                foreach ($dept as $value) {
                                    echo "<option value='" . $value->dept_id . "'>" . $value->dept_name . "</option>";
                                }
                                ?>
                            </select></td></tr>

                    <tr><td>Admins: </td><td><select name="mgrs[]" multiple="managers" size="4">

                                <?php
                                foreach ($admins as $value) {
                                    echo "<option value='" . $value->id . "'";
                                    if ($value->username == "abhijit.r") { //adds selected attribute
                                        echo " selected='selected'";
                                    }
                                    echo ">" . $value->username . "</option>";
                                }
                                ?>
                            </select></td></tr>

                    <tr><td>is_admin: </td><td><input type="checkbox" name="is_admin" value="is_admin"></td></tr>

                    <tr><td colspan="2" align="center"><input type="submit" value="Add User"></td></tr>
                </table>
            </form>
        </div>
        <hr>
        <table border='1'>
<?php
                                echo "<tr><th>User Name</th><th>Dept</th><th>Is Admin</th><th>Total Leave</th><th>Manager</th></tr>";
                                foreach ($users as $value) {
                                    echo "<tr><td>";
                                    echo $value->username;
                                    echo "</td><td>";
                                    echo $value->dept_name;
                                    echo "</td><td>";
                                    echo $value->is_admin;
                                    echo "</td><td>";
                                    echo $value->leave_bal;
                                    echo "</td><td>";
                                    foreach ($mgrs as $val) {
                                        if ($val->user_id == $value->id)
                                            echo $val->mgr;
                                        echo " ";
                                    }
                                    if ($this->session->userdata('is_logged_in') == true && $this->session->userdata('is_admin')) {
                                    echo "</td><td>";
				    echo "<a href=javascript:confirmDelete('" . base_url() . "add_user/delete_user/" . $value->id . "')>Delete</a>";
                                    //echo "<a href=" . base_url() . "add_user/delete_user/" . $value->id . ">Delete</a>";
                                    }
                                    echo "</td><td>";
                                    echo "<a href=" . base_url() . "index.php/add_user/edit_user/" . $value->id . ">_Edit_</a>";
                                    echo "</td><td>";
                                    echo "<a href=" . base_url() . "index.php/add_user/add_remove_mgr/" . $value->id . ">Add/Remove Manager</a>";
                                    echo "</td></tr>";
                                }
?>
                            </table>
                            <br><a href=<?php echo base_url(); ?> >Back to Calendar</a>
    </body>
</html>
