<!DOCTYPE html>

<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html"; charset=utf-8>
              <title>Edit User</title>
    </head>
    <body>

        <div id="login_form">
            <h1>Edit User</h1>
            <?php //echo validation_errors(); ?>
            <?php echo form_open("add_user/update_user/".$id); ?>
           <!-- <form method="post" id="edit_user" name="edit_user"> -->
                <table border="1">
                    <tr><td>User Name: </td><td><input type="text" name="username" value="<?php echo $username; ?>"></td></tr>
                    <tr><td>Leave Balanace: </td><td><input type="text" name="leave_bal" value="<?php echo $leave_bal; ?>"></td></tr>

                    <tr><td>Department: </td><td><select name="dept">
                                <?php
                                foreach ($dept as $value) {
                                    echo "<option value='" . $value->dept_id . "'>" . $value->dept_name . "</option>";
                                }
                                ?>
                            </select></td></tr>

                    <tr><td>is_admin: </td><td><input type="checkbox" name="is_admin" 
                    <?php
                    if ($is_admin==1){
                    	echo "checked='1'";
                    	}
                    	?>
                    	></td></tr>

                    <tr><td colspan="2" align="center"><input type="submit" value="Update"></td></tr>
                </table>
            
        </div>
        
<a href="<?php echo base_url(); ?>index.php/add_user">Cancel</a><br>
<a href=<?php echo base_url();?> >Back to Calendar</a>        
        
    </body>
</html>
