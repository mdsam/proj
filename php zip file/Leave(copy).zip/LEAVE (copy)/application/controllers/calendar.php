<?php

class Calendar extends CI_Controller {

    function index($month = 14, $year=null, $filter = 'all') {

        if ($month == 14) {
            $month = date('n');
        }
        if (!$year) {
            $year = date('Y');
        }

        if ($month > 12) {
            $year = $year + 1;
            $month = 1;
        };
        if ($month < 1) {
            $year = $year - 1;
            $month = 12;
        };

        $data['month'] = $month;
        $data['year'] = $year;
        $days_in_month = cal_days_in_month(0, $month, $year);

        if ($this->session->userdata('is_logged_in') == true) {

            if ($this->session->userdata('is_admin')) {
                $data['msg'] = 'This is user panel <a href=' . base_url() . 'calendar/admin>Admin</a> || <a href=' . base_url() . 'add_user> Manage User</a> || Logged in as: ' . $this->session->userdata('username') . ' || <a href=' . base_url() . 'login/logout> Logout</a>';
            } else {
                $data['msg'] = ' Logged in as: ' . $this->session->userdata('username') . '<a href=' . base_url() . 'login/logout> Logout</a>';
            }
            $query = "SELECT u.username, date_format(ld.date,'%e') as date, lad.reason FROM user u, leave_data ld, leave_app_data lad where u.id = ld.user_id and ld.leave_app_data_id=lad.id and u.username in (select username from user where dept_id=(select dept_id from user where username='" . $this->session->userdata('username') . "')) and date between '$year-$month-01' and '$year-$month-$days_in_month'";
            $data['names'] = $this->Calendar_model->get_names($query);
            $data['leave_taken'] = $this->Calendar_model->leave_taken();
            $data['user_pending_approval'] = $this->Calendar_model->user_pending_approval();
            $data['leave_balance'] = $this->Calendar_model->leave_balance();
            $data['total_leave'] = $this->Calendar_model->total_leave();
            
            $data['right_side_panel'] = 'user/user_right_panel';
            $data['left_side_panel'] = 'user/user_left_panel';
        } else {

//Default View start   
			$dept = $this->Add_user_model->get_dept();
			$filter = $this->uri->segment(5);
			
			$data['msg'] = '<a href=' . base_url() . 'calendar/index/'.$month.'/'.$year.'/all>All</a> || ';
			
			foreach ($dept as $value){
				$data['msg'] .= '<a href=' . base_url() . 'calendar/index/'.$month.'/'.$year.'/'.$value->dept_id.'>'.$value->dept_name.'</a> || ';
				}
            $data['msg'] .= 'You are not logged in <a href=' . base_url() . 'login>Login Here</a>';
			if (!$filter || $filter =='all'){
			            $query = "SELECT u.username, date_format(ld.date,'%e') as date, lad.reason FROM user u, leave_data ld, leave_app_data lad where u.id = ld.user_id and ld.leave_app_data_id=lad.id and date between '$year-$month-01' and '$year-$month-$days_in_month'";
			            
			            $leave_count = "SELECT u.username as username, count(*) as count FROM user u, leave_data ld where u.id = ld.user_id and date between '$year-$month-01' and '$year-$month-$days_in_month' group by u.username";
			            
			            $data['all_pending_approval'] = $this->Calendar_model->all_pending_approval($filter);
			}else{
					$query = "SELECT u.username, date_format(ld.date,'%e') as date, lad.reason FROM user u, leave_data ld, leave_app_data lad where u.id = ld.user_id and ld.leave_app_data_id=lad.id and
					u.dept_id=".$this->uri->segment(5)." and date between '$year-$month-01' and '$year-$month-$days_in_month'";
            
					$leave_count = "SELECT u.username as username, count(*) as count FROM user u, leave_data ld where u.id = ld.user_id and u.dept_id=".$this->uri->segment(5)." and date between '$year-$month-01' and '$year-$month-$days_in_month' group by u.username";
					
					$data['all_pending_approval'] = $this->Calendar_model->all_pending_approval($filter);
            }
            $data['names'] = $this->Calendar_model->get_names($query);
            $data['leave_count'] = $this->Calendar_model->month_leave_count($leave_count);
            			
            $data['right_side_panel'] = 'default/default_right_panel';

            
            $data['left_side_panel'] = 'default/default_left_panel';
        }
//End Default View

        $data['main_content'] = 'cal_main_view';
        $this->load->view('layout/main', $data);
    }

    function admin($month = 14, $year=null) {
        if ($month == 14) {
            $month = date('n');
        }
        if (!$year) {
            $year = date('Y');
        }

        if ($month > 12) {
            $year = $year + 1;
            $month = 1;
        };
        if ($month < 1) {
            $year = $year - 1;
            $month = 12;
        };

        $data['month'] = $month;
        $data['year'] = $year;
        $days_in_month = cal_days_in_month(0, $month, $year);

        if ($this->session->userdata('is_logged_in') == true && $this->session->userdata('is_admin')) {
            $data['msg'] = 'This is admin panel <a href=' . base_url() . 'calendar>User</a> || <a href=' . base_url() . 'add_user>Manage User</a> || Logged in as: ' . $this->session->userdata('username') . ' || <a href=' . base_url() . 'login/logout> Logout</a>';

            $query = "SELECT u.username, date_format(ld.date,'%e') as date, lad.reason FROM user u, leave_data ld, leave_app_data lad where u.id = ld.user_id and ld.leave_app_data_id=lad.id and u.username in (select username from user where dept_id=(select dept_id from user where username='" . $this->session->userdata('username') . "')) and date between '$year-$month-01' and '$year-$month-$days_in_month'";
            $data['names'] = $this->Calendar_model->get_names($query);
            $data['admin_pending_approval'] = $this->Calendar_model->admin_pending_approval();
            $data['total_leave_taken'] = $this->Calendar_model->total_leave_taken();
            $data['total_leave'] = $this->Calendar_model->total_leave();
            $data['total_leave_by_user'] = $this->Calendar_model->total_leave_by_user();

            $data['right_side_panel'] = 'admin/admin_right_panel';
            $data['left_side_panel'] = 'admin/admin_left_panel';
        } else {
            die('You dont have permission to view this page!');
        }

        $data['main_content'] = 'cal_main_view';
        $this->load->view('layout/main', $data);
    }

    function add_leave() {
        if ($this->session->userdata('is_logged_in')) {

            $this->load->helper(array('form', 'url', 'html'));
            $this->load->library('form_validation');

            $this->form_validation->set_rules('reason', '"Reason"', 'required|min_length[3]');
            $this->form_validation->set_rules('dates', '"Dates"', 'required');

            if ($this->form_validation->run() == FALSE) {
                $this->load->view('add_leave/add_leave_view');
            } else {

                $mgr_names = $this->Add_leave_model->apply_leave();
                  $this->send_email_user($this->session->userdata('username').'@directi.com',$this->session->userdata('username'), $_POST['reason'], $_POST['dates']);
                  
                 foreach ($mgr_names as $value) {
          				$mgrs[] = $value->mgr;
          				}
          		$mgr = implode("@directi.com,", $mgrs);
                $this->send_mail_admin($mgr."@directi.com",$this->session->userdata('username'), $_POST['reason'], $_POST['dates']); 
                $this->load->view('add_leave/leave_app_sent');
            }
        }
    }

    function approve_leave($id) {

        $leave_approved = $this->Add_leave_model->approve_leave($id);

        	 foreach ($leave_approved as $value) {
          $username = $value->username;
          $dates = $value->dates;
          $reason = $value->reason;
          }
          
          $this->approval_email_hr('hrops@directi.com', $this->session->userdata('username'), $dates, $username, $reason);
          $this->approval_email_user($username.'@directi.com', $dates, $username, $reason, $this->session->userdata('username'));
          
        redirect('calendar/admin');
    }

    function decline_leave($id) {

        $leave_decline = $this->Add_leave_model->decline_leave($id);

        	 foreach ($leave_decline as $value) {
          $username = $value->username;
          $dates = $value->dates;
          $reason = $value->reason;
          $decline_reason = $_POST['dec_data'];
          }

          $this->decline_email_user($username, $dates, $reason, $decline_reason, $this->session->userdata('username'));
          redirect('calendar/admin');
    }
    
    	function send_email_user($to, $name, $reason, $dates) {

       
        $subject = "Leave Application of " . $name;

        //begin of HTML message
        $message =
                "<html>
                <body bgcolor=\"#DCEEFC\">

         Hello " . /*$_POST['name'] .*/ ",<br><br>
            Below are the details for your leave application:
				<br><br>
             This is leave application for date/s: <b>" . $dates . "</b>
            <br><i>Reason: </i><b>" . $reason . "</b><br><br>

              <b>Your Leave Application is currently under review. Should get an update shortly.</b>

                    </body>
                            </html>";
        //end of message
        // To send the HTML mail we need to set the Content-type header.

        $headers = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        $headers .= 'From: Admin <leave.admin@directi.com>' . "\r\n";



        //options to send to cc+bcc
        //$headers .= "Bcc: [email]email@maaking.cXom[/email]";
        // now lets send the email.
        mail($to, $subject, $message, $headers);
    }

    function approval_email_user($to, $dates, $name, $reason, $manager_name) {

        
        $subject = "Leave has been Approved!";

        //begin of HTML message
        $message =
                "<html>
                <body bgcolor='#DCEEFC'>

         Hello,<br><br>

            This leave application has been approved. Below are the details for the same :-
            <br><br>
            Leave Dates : <b>  " . $dates . "</b>
            <br><i>Reason: </i><b>" . $reason . "</b>
		<br><br>

                    Regards,<br>
                " . $manager_name . "<br>
                    </body>
                            </html>";
        //end of message
        // To send the HTML mail we need to set the Content-type header.

        $headers = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        $headers .= "From: ".$manager_name."<".$manager_name."@directi.com>" . "\r\n";



        //options to send to cc+bcc
        //$headers .= "Bcc: [email]email@maaking.cXom[/email]";
        // now lets send the email.
        mail($to, $subject, $message, $headers);
    }

    function decline_email_user($name, $dates, $reason, $dec_reason, $manager_name) {

        
			$to = $name.'@directi.com';
			
        $subject = "Leave has been Declined!";

        //begin of HTML message
        $message =
                "<html>
                <body bgcolor='#DCEEFC'>

         Hello  " . $name . ",<br><br>

            This leave application has been declined for the following reason:-
            <br><br>
            <b>Leave Dates :   " . $dates . "</b>
            <br><i>Reason: </i><b>" . $reason . "</b>
		<br><br>
            Declined reason: <b>" . $dec_reason . "</b>
			<br><br>
                    Regards,<br>
                " . $manager_name . "<br>
                    </body>
                            </html>";
        //end of message
        // To send the HTML mail we need to set the Content-type header.

        $headers = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        $headers .= "From: ".$manager_name."<".$manager_name."@directi.com>" . "\r\n";



        //options to send to cc+bcc
        //$headers .= "Bcc: [email]email@maaking.cXom[/email]";
        // now lets send the email.
        mail($to, $subject, $message, $headers);
    }
    
    function send_mail_admin($tl, $name, $reason, $dates) {

        
        $subject = "Leave Application of " . $name;

        //begin of HTML message
        $message =
                "<html>
                <body bgcolor='#DCEEFC'>

         Hello,<br><br>
             This is leave application for dated: <b>" . $dates . "</b>
            <br><i>Reason: </i><b>" . $reason . "</b>
            <br>Kindly grant my leave.<br><br>

                Thank You !<br><br>

                    Regards,<br>
                " . $name . "<br><br>

                To Approve or Decline the leave application, click on the below link:-
                  <br><br>
                    <a href='http://support/leave'>Click here</a>

                    </body>
                            </html>";
        //end of message
        // To send the HTML mail we need to set the Content-type header.

        $headers = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        $headers .= "From: ".$name."<".$name."@directi.com>" . "\r\n";



        //options to send to cc+bcc
        //$headers .= "Bcc: [email]email@maaking.cXom[/email]";
        // now lets send the email.
        mail($tl, $subject, $message, $headers);
    }
    
	function approval_email_hr($to, $manager_name, $dates, $name, $reason) {

        
        $subject = "Please Make a note of this leave application for " . $name;

        //begin of HTML message
        $message =
                "<html>
                <body bgcolor='#DCEEFC'>

         Hello HR,<br><br>

            <b>This leave application has been approved.</b>
	    <br><br>
	    Below are the details for the same :-
            <br><br>
             Username :   <b>" . $name . "</b><br>
             Leave Dates :   <b>" . $dates . "</b>
            <br><i>Reason: </i><b>" . $reason . "</b>
		<br><br>

		Kindly make a note of this.
				<br><br>

                    Regards,<br>
                " . $manager_name . "<br>
                    </body>
                            </html>";
        //end of message
        // To send the HTML mail we need to set the Content-type header.

        $headers = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        $headers .= "From: ".$manager_name."<".$manager_name."@directi.com>" . "\r\n";



        //options to send to cc+bcc
        //$headers .= "Bcc: [email]email@maaking.cXom[/email]";
        // now lets send the email.
        mail($to, $subject, $message, $headers);
    }
    
}
?>
