<?php

class Add_user extends CI_Controller {

    function index() {
/*        if (!($this->session->userdata('is_logged_in') == true && $this->session->userdata('is_admin'))) {
            die('You dont have permission to view this page!');
        }
        
        if (!($this->session->userdata('username') == 'vijay.r' || $this->session->userdata('username') == 'latesh.ch')) {
            die('You dont have permission to view this page!');
        }*/        
        
        $data['dept'] = $this->Add_user_model->get_dept();
        $data['admins'] = $this->Add_user_model->get_admin();
        $data['users'] = $this->Add_user_model->get_users();
        $data['mgrs'] = $this->Add_user_model->get_mgrs();

        $this->load->view('add_user/add_user_view', $data);
    }

    function add() {

        if (isset($_POST['is_admin'])) {
            $data['is_admin'] = 1;
        } else {
            $data['is_admin'] = 0;
        }

        $user = array(
            'username' => $_POST['username'],
            'leave_bal' => $_POST['leave_bal'],
            'dept_id' => $_POST['dept'],
            'is_admin' => $data['is_admin'],
        );

        $data['username'] = $_POST['username'];
        $data['leave_bal'] = $_POST['leave_bal'];
        $data['department'] = $_POST['dept'];
        
        $umgr['mgr_id'] = $_POST['mgrs'];

        $mgr = $this->Add_user_model->add_user($user);

        foreach ($mgr as $value) {
            $umgr['user_id'] = $value->id;
        }

        $this->Add_user_model->add_user_mgr($umgr);
        $this->load->view('add_user/user_added_view');
    }

    function delete_user($id) {
        $this->Add_user_model->delete_user($id);
        $this->load->view('add_user/add_user_view');
        redirect('add_user');
    }
    
    function edit_user($id) {
    	$data['dept'] = $this->Add_user_model->get_dept();
        $data['admins'] = $this->Add_user_model->get_admin();

		  $user_data = $this->Add_user_model->edit_user($id);

       foreach ($user_data as $value) {
       		$data['id'] = $id;
				$data['username'] = $value->username;
				$data['leave_bal'] = $value->leave_bal;
				$data['is_admin'] = $value->is_admin;
        }

        $this->load->view('add_user/edit_user_view', $data);

    }
    
    function update_user($id) {

    	   if (isset($_POST['is_admin'])) {
            $data['is_admin'] = 1;
        } else {
            $data['is_admin'] = 0;
        }

        $user = array(
        		'id' => $id,
            'username' => $_POST['username'],
            'leave_bal' => $_POST['leave_bal'],
            'dept_id' => $_POST['dept'],
            'is_admin' => $data['is_admin'],
        );
    	
		  $this->Add_user_model->update_user($user);
        redirect('add_user');
    } 
    
    function add_remove_mgr($id) {
    	  $user = $this->Add_user_model->get_user($id);
    	  $data['mgr'] = $this->Add_user_model->get_mgr($id);
    	  $data['admin'] = $this->Add_user_model->get_admin();

       foreach ($user as $value) {
       		$data['id'] = $id;
				$data['username'] = $value->username;
				$data['department'] = $value->dept_name;
				$data['leave_bal'] = $value->leave_bal;
				$data['is_admin'] = $value->is_admin;
        }

        $this->load->view('add_user/add_remove_mgr', $data);
    	}
    	
    function update_mgrs($id) {
			$umgr['mgr_id'] = $_POST['mgrs'];
			$umgr['user_id'] = $id;
			$this->Add_user_model->update_user_mgr($umgr);	
			redirect('add_user');    		
    		}
}
?>
