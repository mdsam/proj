<?php

class Login extends CI_Controller {

    function index() {

        $this->load->library('form_validation');

        $this->form_validation->set_rules('username', 'Username', 'required|min_length[3]');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('login/login_view');
        } else {
            $this->validate_credentilas();
        }
    }

    function validate_credentilas() {
        $this->load->model('login_model');

        $data['username'] = $this->input->post('username');
        $data['password'] = $this->input->post('password');

        $query = $this->login_model->validate($data);

        if ($query == 'success') {
            $user_details = $this->login_model->user_details($data);

            $data['username'] = $this->input->post('username');
            $data['is_logged_in'] = true;

            foreach ($user_details as $value) {
                //$data['mgr'] = $value->mgr_id;
                $data['is_admin'] = $value->is_admin;
            }

            $this->session->set_userdata($data);

            redirect('calendar');
        } else {
            redirect('login');
        }
    }

    function logout() {
        $this->session->sess_destroy();
        redirect('calendar');
    }

}

?>
