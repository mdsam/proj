<center><b>Weekend events:<b><br><br>

Debate competiton(E/H)<br>

Poetry inter college competiton<br>

Basket ball competition<br></center>