<h1 style="color:#000000"><b><center>Contact Details</center></b></h1>
<div align="center">
<p><b>Address :</b> ABC Engineering College, XYZ Group, Near AIIMS, New Delhi.
<p><b>Phone :</b> 0120-567584985<br>
<b>Mobile :</b> 09189787182
</p>
<p><b>Fax :</b> 0120-8976764-65-66</p>
<p><b>Email :</b> admission@abcxya.com</p>
</p>
</div>