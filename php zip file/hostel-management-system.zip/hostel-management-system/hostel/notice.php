
<center><b>Notice Board:</b><br><br>

college reopens on 5th august<br><br>

sessionals to be announced soon<br><br>

student development seminar on 12th aug'14<br></center>