<?php
  // Define application constants
  define('GW_UPLOADPATH', 'images/');
?>
