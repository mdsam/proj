<?php
  // Define database connection constants
  define('DB_HOST', 'data.riskyjobs.biz');
  define('DB_USER', 'admin');
  define('DB_PASSWORD', 'danger');
  define('DB_NAME', 'riskyjobs');
?>
